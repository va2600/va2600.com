#!/bin/bash

###sudo chmod +s /usr/bin/screen
###sudo chmod 755 /var/run/screen

screen -d -m -S webscreen 
sleep 1

#screen -S webscreen -X multiuser on
#sleep 1

#screen -S webscreen -X acladd www-data
#sleep 1

./ttysize.sh

screen -S webscreen -X exec `php-cgi hcloop.php &`

#screen -S webscreen -X aclchg www-data +r+w+x "#"

#screen -S webscreen -X writelock off
