#!/bin/sh
stty --file=`tty` size > ttysize
