netstat -ac --numeric-ports | grep -i "estab" | grep -v "tcp6|LISTEN" | grep ":80"
